<?php

//error_reporting(0);

require('config.php');

$name = $_REQUEST['name'];
$email = $_REQUEST['email'];
$contact = $_REQUEST['contact'];
$password = $_REQUEST['password'];
$gender = $_REQUEST['gender'];
$city = $_REQUEST['city'];

//echo $name.' '.$email.' '.$contact.' '.$password.' '.$gender.' '.$city;

$CheckQuery = "select * from users WHERE email='".$email."' OR contact='".$contact."'";

$resultCheck = $db_con->query($CheckQuery);

$rowCountCheck = $resultCheck->num_rows;

if($rowCountCheck>0){
	$data = array('Status'=> 'False', 'Message'=>"User Already Exists");
	print(json_encode($data));
	exit;
}
else{
	$insertQuery = "insert into users (`type`,`name`,`email`,`contact`,`password`,`gender`,`city`) VALUES('User','".$name."','".$email."','".$contact."','".$password."','".$gender."','".$city."')";

	$result = $db_con->query($insertQuery);

	if($result){
		//echo "Success";
		$data = array('Status'=> 'True', 'Message'=>"Signup Successfully");
		print(json_encode($data));
		exit;
	}
	else{
		//echo "Unsuccess";
		$data = array('Status'=> 'False', 'Message'=>"Signup Unsuccessfully");
		print(json_encode($data));
		exit;
	}
}
?>