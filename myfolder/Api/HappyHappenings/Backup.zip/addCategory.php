<?php
require('config.php');

					$name = $_REQUEST['name'];
					
					$filename= $_FILES['file']['name'];
					$file_temp = $_FILES['file']['tmp_name'];		
				    //UPLOAD PATH INFO	IMAGE			
					$upload_path = 'category/'; 
					
					$upload_url = $server_path.$upload_path;
				    $fileinfo = pathinfo($filename);
				    $extension = $fileinfo['extension'];
					
					$file_url =  $name.'_'.'.'.$extension;
				    $file_path = $upload_path.$name.'_'.'.'.$extension;
					
					$select = $db_con->query("SELECT * FROM `category` WHERE `name`='".$name."'");
					$userCount = $select->num_rows;
					if($userCount>0){
						$data = array('Status'=>'False','Message'=>'Category already exists.');	
						print(json_encode($data));
						exit;
					}else{
						move_uploaded_file($file_temp,$file_path); 
						$sql_query = "INSERT INTO `category`(`name`,`image`) VALUES ('".$name."','".$file_url."');";
	 
	                    $result = $db_con->query($sql_query);
						
	                    if($result)
						{
	                       $data =array('Status'=>'True','Message'=>'Category Added Successfully');
						   print(json_encode($data));
						   exit;
						}
						else
						{
						  $data = array('Status'=>'False','Message'=>'Category Added Unsuccessfully');	
						  print(json_encode($data));
						  exit;
						}
					}

 mysqli_close($db_con);   
?>

