<?php

$db_host = "localhost";
$db_username = "id18229198_happy_happenings_user";
$db_password = "User@Google007";
$db_name = "id18229198_happy_happenings";

$db_con = mysqli_connect($db_host,$db_username,$db_password,$db_name) or die("Database Error");

$server_path = "https://happyhappenings13.000webhostapp.com/HappyHappenings/";
$category_path = "https://happyhappenings13.000webhostapp.com/HappyHappenings/category/";

?>